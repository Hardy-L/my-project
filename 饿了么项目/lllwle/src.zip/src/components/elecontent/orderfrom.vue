<template>
<!--订单部分-->
  <div>    hello  order.vue</div>
</template>
<script>
export default {
name:'orderfrom'
}
</script>
<style>

</style>
