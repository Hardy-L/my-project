<template>
<!--我的部分-->
  <router-link to="/slide"> hello  my-ele.vue</router-link>
</template>
<script>
import slide from './slide';
export default {
name:'myele',
}
</script>
<style>


</style>
