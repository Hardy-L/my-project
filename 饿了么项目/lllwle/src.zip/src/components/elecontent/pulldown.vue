<template>
<div>
 <div class="title">
     <div class="left tong">
         <div @click="dianji()">分类</div>
         </div>
          
     <div class="center tong">排序</div>
     <div class="right tong">筛选</div>
 </div>
 <div v-show="value1">
     <div>
         <div v-if="0">异国料理</div>
         <div v-if="1"><span class="tu"></span> <span class="wen">餐饮便当</span></div>
     </div>
 </div>
</div>
</template>
<script>
    export default {
     data:() =>({
         value1:false
     }),
     methods:{
         dianji:function (){
             this.value1 = !this.value1
         }
     }
  }
</script>
<style scoped>
  .title{
      display:flex;
   border-bottom: 1px solid gray;
  }
  .tong{
      width: 33%;
      text-align: center;
      padding:  0.3rem 0;
      margin: 0.6rem 0;
  }
  .center{
      border-left: 0.1rem solid gray;
      border-right: 0.1rem solid gray;
  }
</style>