<template>
<!--导航栏-->
<div class="head">
   <i class="el-icon-search"></i>
   <p class="log-in">甜品饮品</p>
  </div>
</template>
<script>

    export default{
     name:'titleaaa',
  //    data(){
  //      return{
  //        shopId:""
  //      }
  //    }
  
  // created(){
  //    var id =  this.$router.params.nameID
  //    ...
  //    _this.shopId=data
  // }
    }
    </script>
<style>
    * {
  margin: 0 auto;
  padding: 0 auto;
}
.body {
  position: relative;
}
.head {
  width: 100%;
  height: 2.3em;
  background-color: blue;
  overflow: hidden;
  border: 1px solid red;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 10;
}
.el-icon-search {
  float: left;
  font-size: 2.0em;
}
.log-in {
 text-align: center;
  font-size: 1.5em;
}
</style>