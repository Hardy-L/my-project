<template>
<!--  商品列表-->
    <div>
        <!-- <titleaaa></titleaaa> -->
       <div class="merchant-list">
        <p v-for="mls in data6" :key="mls.id" class="merchant-list-single">
          <router-link to=""><!-- btns(mls.id) -->
              <div class="flex">
                <img :src="'https://elm.cangdu.org/img/'+mls.image_path" alt="" class="flex-left">
                <div class="flex-right">
              <div class="flex-right-top mutual">
                <div class="flex-right-top-left"><span class="pinpai">品牌</span>
                <strong class="shoppingname">{{mls.name}}</strong>
                </div>
                <div class="flex-right-top-right">保准票</div>
              </div>
              <div class="flex-right-content mutual">
                <div class="flex-right-content-left">
                  <div class="block">
                       <span class="star"><el-rate v-model="mls.rating" disabled show-score text-color="#ff9900" score-template="{value}">
                   </el-rate></span>
                       <span class="yueshou">月售{{mls.recent_order_num}}单</span>
                   </div>
                </div>
                <div class="flex-right-content-right">
                 <span class="fengniao">蜂鸟专送</span> 
                 <span class="zhunshi">准时达</span>
                  </div>
              </div>
              <div class="flex-right-bottom mutual">
                <div class="flex-right-content-left">¥{{mls.float_minimum_order_amount}}起送/配送费约¥{{mls.float_delivery_fee}}</div>
                <div class="flex-right-tocontentp-right">
                  <span class="gongli">{{mls.distance}}/</span>
                  <span class="time">{{mls.order_lead_time}}</span>
                </div>
              </div>
              </div>
             </div>
            </router-link>
             </p>
             </div>
             <router-view></router-view>
             </div>
</template>
<script>
// import titleaaa from "./titleaaa";
export default {
  name: "merchantlist",
  data: () => ({
    data6: [],
    value5: 3.7
  }),
  created() {
    // 接口 6
    var _this = this;
    var api6 =
      "https://elm.cangdu.org/shopping/restaurants?latitude=31.22967&longitude=121.4762";

    this.$http.get(api6).then(data => {
      params: {
        //  latitude=31.22967,
        //   longitude=121.4762
      }
      //关闭加载提示
      // loadingInstance1.close();
      // 成功后的回调
      console.log("成功了....");
      //展示所有商店名
      console.log(data);
      _this.data6 = data.data;
      console.log(_this.data6);
    });
  },
  // methods:{
  //   btns(el){
  //     el
  //   }
  // }
};
</script>
<style scoped>
.flex{
  overflow: hidden;
  border:1px solid red;
}
.merchant-list{
margin: 0.8rem 0.8rem 0 0.4rem;
}
.flex-left{
  float: left;
  width: 20%;
  padding: 3%;
}
.flex-right{
  float: right;
  width: 70%;
 
}
.mutual{
 overflow: hidden;
}
.flex-right-top-left{
  float: left;
}
.flex-right-top-right{
  float: right;
  color: gray;
font-size: 0.1rem;
}
.pinpai{
color: black;
/* border: 1px solid black; */
background-color: yellow;
font-size: 0.1rem;
border-radius: 0.3rem;
padding: 0 0.3rem;
margin: 0 0.8rem 0 0;
}
.shoppingname{
  color: black;
  font-size: 0.5em;
}
flex-right-content-left{
   float: left;
}
flex-right-content-right{
   float: right;
}
.yueshou{
  color: rgb(68, 65, 65);
  font-size: 0.1em;
}
</style>
<style>
  <style>
  .el-rate__item{
    width: 0.094rem;
  }
  .el-rate__icon{
    font-size: .01rem;
  }
  .el-rate__text{ 
    font-size: 0.01rem;
  }
</style>
