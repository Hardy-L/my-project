import Vue from "vue";
import Router from "vue-router";
import HelloWorld from "@/components/HelloWorld";
import elecontent from "../components/elecontent/elecontent";
import seatch from "../components/elecontent/seatch";
import orderfrom from "../components/elecontent/orderfrom";
import myele from "../components/elecontent/myele";
import merchantlist from "../components/elecontent/merchantlist";
import titleaaa from "../components/elecontent/titleaaa";
import slide from "../components/elecontent/slide";
import pullown from "../components/elecontent/pulldown";
// import { Swipe, SwipeItem } from 'vue-swipe';
Vue.use(Router);

export default new Router({
  routes: [
    // {
    //   path: "/",
    //   component: elecontent
    // },
    {
      path: "/elecontent",
      name: "elecontent",
      component: elecontent
    },
    {
      path: "/seatch",
      name: "seatch",
      component: seatch
    },
    {
      path: "/orderfrom", //跳转地址
      name: "orderfrom",
      component: orderfrom
    },
    {
      path: "/myele",
      name: "myele",
      component: myele
    },
    {
      path: "/merchantlist",
      name: "merchantlist",
      component: merchantlist
    },
    {
      path: "/titleaaa",
      name: "titleaaa",
      component: titleaaa
    },
    {
      path: "/slide",
      name: "slide",
      component: slide
    },
    {
      path: "/pullown",
      name: "pullown",
      component: pullown
    }
  ]
});
