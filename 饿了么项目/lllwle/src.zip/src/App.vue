<template>
 <div class="warp">

   <div class="body">
    <div class="body-top">
    <elecontent></elecontent>
    </div>
    <div class="body-bottom">
<merchantlist></merchantlist>
    </div>
   </div>
   <div class="bottom">
     <!-- 外卖 -->
       <router-link to="/elecontent" class="icon">
       <span class="icon-img"><img src="./assets/放大镜.png" alt=""></span>
       <span class="icon-wenzi">外卖</span>
       </router-link>
       <!-- 搜索 -->
     <router-link to="/seatch" class="icon">
     <span class="icon-img"><img src="./assets/3搜索2.png" alt=""> </span>
       <span class="icon-wenzi">搜索</span>
       </router-link>
       <!-- 订单 -->
     <router-link to="/orderfrom" class="icon">
     <span class="icon-img"><img src="./assets/订单.png" alt=""></span>
       <span class="icon-wenzi">订单</span>
       </router-link>


       <!-- 我的 -->
    <router-link to="/myele" class="icon">
    <span class="icon-img"><img src="./assets/个人中心.png" alt=""></span>
       <span class="icon-wenzi">我的</span>
       </router-link>

   </div>
<router-view></router-view>
 </div>
</template>
<script>
//引入外卖页面
import elecontent from "./components/elecontent/elecontent";
// 引入搜索页面
import seatch from "./components/elecontent/seatch";
//引入订单页面
import orderfrom from "./components/elecontent/orderfrom";
//引入我的页面
import myele from "./components/elecontent/myele";
// 商家页面
import merchantlist from "./components/elecontent/merchantlist";
export default {
  name: "App",
  components: {
    elecontent,
    seatch,
    orderfrom,
    myele,
    merchantlist
  }
};
</script>
<style scoped>
* {
  margin: 0 auto;
  padding: 0 auto;
}
.body {
  position: relative;
}
/* .head {
  background-color: blue;
  overflow: hidden;
  border: 1px solid red;
  position: relative;
}
.el-icon-search {
  float: left;
}
.log-in {
  float: right;
}
.log-in span {
  color: aliceblue;
} */
.bottom {
  width: 100%;
  background-color: blue;
  /* border: 1px solid red; */
  display: flex;
  position: fixed;
  bottom: 0em;
  left: 0em;
}
.icon {
  /* border: 2px solid black; */
  width: 25%;
  display: flex;
  flex-direction: column;
  text-align: center;
}
.icon .icon-img img {
  width: 2rem;
}
.icon .icon-wenzi {
  color: white;
}
.body-top{
  height: 13.35rem;
  overflow: hidden;
}
</style>
