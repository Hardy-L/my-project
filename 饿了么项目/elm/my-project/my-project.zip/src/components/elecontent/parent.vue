
<!--  公用的父组件->
import Vue from 'Vue'
export default new Vue({
    
})