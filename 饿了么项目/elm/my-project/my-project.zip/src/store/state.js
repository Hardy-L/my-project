// 相当于data    vuex中的数据源，我们可以通过 this.$store.state 获取我们在vuex中声明的全局变量的值。
export default{
   usermsg:{},
   username:"",
   password:"",
   src:"",
   captcha_code:"",
   bool:false,
   sousuo:"",
   bbb:"",
   datahe:[],
   // 点击获取到的当前对象
   dqdata:[],
   // 钱数
   qian:"",
   // 把选择的对象存入数组
   xzdata:[],
   num:0,


   homeid:"",
   price:"",
   id:"",
   limit:""
// $store.state.homeid
}